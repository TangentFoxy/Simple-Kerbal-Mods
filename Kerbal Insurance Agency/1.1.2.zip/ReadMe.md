This mod adds a simple agency representing an insurance company.

The Kerbal Insurance Agency was formed before Kerbals realized that going into space was very dangerous. Due to legal issues, the company still exists, despite having tried to go backrupt several times.

Based on a flag created by Reddit user SlowCPU.

#### Mentalities:

- Competitive 0.8
- Economic 1
- Hasty 0.6
- Perfectionist 0.1
- Stern 1
- Kerbalminded 0.9
- Moral 0.4
