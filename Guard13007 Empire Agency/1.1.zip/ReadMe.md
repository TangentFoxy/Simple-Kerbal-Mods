This mod adds a simple agency. Read the [KerbalStuff](http://beta.kerbalstuff.com/mod/68)
description about it for more info.
