This mod adds an agency representing the somewhat evil Guard13007 Empire.

The Guard13007 Empire is a hasty, scientific, pioneering group that doesn't
really care about Kerbal life and will pay you greatly for your assistance. Do
well for them and you will be rewarded. Do badly, and they don't really care,
but you won't be paid.

#### Mentalities

- Commercial 0.8
- Competitive 0.9
- Conglomerate 0.7
- Hasty 0.6
- Industrial 0.7
- Perfectionist 1
- Pioneer 0.8
- Scientific 0.9
- EasyGoing 1
- Kerbalminded 0
- Moral 0

Note that I may not understand how these actually work and some are not
implemented in the stock game, and thus, do nothing.
